package machinetest;

import org.testng.annotations.Test;

public class PunchIn {
	@Test
	public void punchIn() {

	}
}
